package reto4.view;

import reto4.controller.ReportesController;
import reto4.model.vo.*;
import java.util.List;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ReportesView extends JFrame implements ActionListener {
    private ReportesController controller;
    private JButton Inf1, Inf2, Inf3;
    private JTable tabla;
    private DefaultTableModel modelo;
    private JLabel lblTitulo, lblConsulta;

    public ReportesView() {
        controller = new ReportesController();
        botones();        
        etiqueta1();
        etiqueta2();
        tabla();
    }

    public void tabla() {
        tabla = new JTable(modelo);
        tabla.setPreferredScrollableViewportSize(new Dimension(500,200));
        add(tabla);
        JScrollPane pane = new JScrollPane(tabla);
        add(pane);
    }

    public void etiqueta1() {
        lblTitulo = new JLabel("Informes Reto 5");
        lblTitulo.setPreferredSize(new Dimension(500,30) );
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        add(lblTitulo);
    }
    public void etiqueta2() {
        lblConsulta = new JLabel();
        lblConsulta.setSize(500, 30);
        lblConsulta.setFont(new Font("Arial", Font.BOLD, 14));
        add(lblConsulta);
    }
    public void botones(){
        Inf1 = new JButton("Informe 1");
        Inf2 = new JButton("Informe 2");
        Inf3 = new JButton("Informe 3");
        add(Inf1);
        add(Inf2);
        add(Inf3);
        Inf1.addActionListener(this);
        Inf2.addActionListener(this);
        Inf3.addActionListener(this);
    }
    
    public void Informe2() {        
        try{
            List<ProyectosVo> proyectos = controller.listarProyectos();
            modelo = new DefaultTableModel();
            modelo.addColumn("Id Proyecto");
            modelo.addColumn("Constructora");
            modelo.addColumn("Habitaciones");
            modelo.addColumn("Ciudad");
            for (ProyectosVo proyecto: proyectos){
                Object[] fila = new Object[4];
                fila[0] = proyecto.getId();
                fila[1] = proyecto.getConstructora();
                fila[2] = proyecto.getHabitaciones();
                fila[3] = proyecto.getCiudad(); 
                
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }            
        
    }
    public void Informe3() {       
        try{
            List<HomecenterVo> Homec = controller.listarHomecenter();
            modelo = new DefaultTableModel();
            modelo.addColumn("ID_Compra");
            modelo.addColumn("Constructora");
            modelo.addColumn("Banco_Vinculado");
            for (HomecenterVo proyectoH: Homec){
                Object[] fila = new Object[4];
                fila[0] = proyectoH.getId();
                fila[1] = proyectoH.getConstructora();
                fila[2] = proyectoH.getBanco();                
                
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        
    }
    public void Informe1() {
        
        try{
            List<ListaLideresVo> lideres = controller.listarLideres();
            modelo = new DefaultTableModel();
            modelo.addColumn("Id Lider");
            modelo.addColumn("Nombre");
            modelo.addColumn("Apellido");
            modelo.addColumn("Ciudad");

            for (ListaLideresVo lider : lideres){
                Object[] fila = new Object[4];
                fila[0] = lider.getId();
                fila[1] = lider.getNombre();
                fila[2] = lider.getApellido();
                fila[3] = lider.getCiudad(); 
                
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            modelo.fireTableDataChanged();

        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Inf1){
            Informe1();
            lblConsulta.setText("Informe de Líderes");
        }
        if (e.getSource() == Inf2){
            Informe2();
            lblConsulta.setText("Informe de Proyectos");
        }
        if (e.getSource() == Inf3){
            Informe3();
            lblConsulta.setText("Informe Homecenter");

        }

        
    }

    
    
}
